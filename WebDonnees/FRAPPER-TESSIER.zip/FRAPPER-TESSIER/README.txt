Executer le fichier execution pour executer les différents programmes 
Le 2 versions JDOM vont créer le meme fichier "cible.xml"
les autrs vont créer un fichier qui commencera par "exo_"